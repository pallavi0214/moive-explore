import { Link, Route, Routes } from 'react-router-dom'
import { Home, Detail } from './pages'
export default function App() {
  return (<>
    <header><Link to="/">Movie Explorer</Link></header>
    <main><Routes>
      <Route path="/" element={<Home />} />
      <Route path="/movie/:id" element={<Detail />} />
      <Route path="*" element={<p className="state">Page not found. <Link to="/">Back to movies</Link></p>} />
    </Routes></main></>)
}
