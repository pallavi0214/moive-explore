import { useEffect, useState } from 'react'
import { api } from './api'

// Fetches on every change of path/params, cancels stale requests.
export function useApi(path, params = {}) {
  const [state, setState] = useState({ data: null, loading: true, error: null })
  const key = path + JSON.stringify(params)
  useEffect(() => {
    const ctrl = new AbortController()
    setState(s => ({ ...s, loading: true, error: null }))
    api(path, params, ctrl.signal)
      .then(data => setState({ data, loading: false, error: null }))
      .catch(e => e.name !== 'AbortError' && setState({ data: null, loading: false, error: e.message }))
    return () => ctrl.abort()
  }, [key])
  return state
}

export function useDebounce(value, ms = 500) {
  const [v, setV] = useState(value)
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t) }, [value, ms])
  return v
}
