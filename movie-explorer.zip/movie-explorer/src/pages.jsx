import { Link, useParams } from 'react-router-dom'
import { useApi, useDebounce } from './hooks'
import { useSearch } from './context'
import { img } from './api'

const Status = ({ s, children }) => s.error ? <p className="state err" role="alert">{s.error}</p>
  : s.loading ? <div className="state"><span className="spinner" />Loading…</div> : children

const Rating = ({ v }) => <span className="rating" title="Average user rating">★ {v ? v.toFixed(1) : 'NR'}</span>

function MovieCard({ m }) {
  return (<Link to={`/movie/${m.id}`} className="card">
    {img(m.poster_path) ? <img src={img(m.poster_path)} alt={`${m.title} poster`} loading="lazy" />
      : <div className="noimg">No poster</div>}
    <div><h3>{m.title}</h3>
      <p><Rating v={m.vote_average} /> <span>{(m.release_date || '').slice(0, 4)}</span></p></div></Link>)
}

export function Home() {
  const { query, genre, page, setPage, setQuery, setGenre } = useSearch()
  const q = useDebounce(query.trim())
  const genres = useApi('/genre/movie/list')
  const list = useApi(
    q ? '/search/movie' : genre ? '/discover/movie' : '/movie/popular',
    q ? { query: q, page } : genre ? { with_genres: genre, page, sort_by: 'popularity.desc' } : { page })
  const results = list.data?.results || []
  const pages = Math.min(list.data?.total_pages || 1, 500)
  return (<>
    <input className="search" type="search" placeholder="Search movies by title" aria-label="Search movies"
      value={query} onChange={e => setQuery(e.target.value)} />
    <div className="chips" role="group" aria-label="Category filter">
      <button className={!genre ? 'on' : ''} onClick={() => setGenre(0)}>All</button>
      {genres.data?.genres.map(g => <button key={g.id} className={genre === g.id ? 'on' : ''}
        onClick={() => setGenre(g.id)}>{g.name}</button>)}</div>
    <p className="muted">{q ? `Results for “${q}”` : genre ? 'Popular in this category' : 'Popular right now'}
      {q && genre ? ' (category filter applies when search is empty)' : ''}</p>
    <Status s={list}>
      {results.length === 0 ? <p className="state">No movies found. Try a different title.</p>
        : <div className="grid">{results.map(m => <MovieCard key={m.id} m={m} />)}</div>}
      <nav className="pager"><button disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
        <span>Page {page} of {pages}</span>
        <button disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</button></nav>
    </Status></>)
}

export function Detail() {
  const { id } = useParams()
  const s = useApi(`/movie/${id}`, { append_to_response: 'credits' })
  const m = s.data
  return (<><Link to="/" className="back">Back to movies</Link>
    <Status s={s}>{m && <article className="detail">
      {img(m.poster_path, 'w500') && <img src={img(m.poster_path, 'w500')} alt={`${m.title} poster`} />}
      <div><h2>{m.title}</h2>
        {m.tagline && <p className="tag">{m.tagline}</p>}
        <p><Rating v={m.vote_average} /> · {m.release_date} · {m.runtime} min</p>
        <p className="chips">{m.genres.map(g => <span key={g.id} className="on">{g.name}</span>)}</p>
        <p>{m.overview || 'No overview available.'}</p>
        <p className="muted">Cast: {m.credits.cast.slice(0, 6).map(c => c.name).join(', ') || 'Not listed'}</p>
      </div></article>}</Status></>)
}
