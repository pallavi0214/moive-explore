import { createContext, useContext, useState } from 'react'
const Ctx = createContext()
export const useSearch = () => useContext(Ctx)
// Keeps query/genre/page when you open a movie and press Back.
export function SearchProvider({ children }) {
  const [query, setQuery] = useState('')
  const [genre, setGenre] = useState(0)
  const [page, setPage] = useState(1)
  const change = fn => v => { fn(v); setPage(1) }
  return <Ctx.Provider value={{ query, genre, page, setPage, setQuery: change(setQuery), setGenre: change(setGenre) }}>
    {children}</Ctx.Provider>
}
