// Public movie API: TMDB (free key at themoviedb.org/settings/api)
const KEY = import.meta.env.VITE_TMDB_KEY
const BASE = 'https://api.themoviedb.org/3'
export const img = (p, size = 'w342') => p ? `https://image.tmdb.org/t/p/${size}${p}` : null

export async function api(path, params = {}, signal) {
  if (!KEY) throw new Error('Missing API key. Add VITE_TMDB_KEY to your .env file.')
  const qs = new URLSearchParams({ api_key: KEY, ...params })
  const res = await fetch(`${BASE}${path}?${qs}`, { signal })
  if (!res.ok) throw new Error(res.status === 401 ? 'Invalid API key.' : 'Request failed. Try again.')
  return res.json()
}
