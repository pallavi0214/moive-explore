# Movie Explorer (Module 4 Take-Home Assignment)
React 18 + React Router + Hooks + Context API, using the TMDB public movie API.

## Setup
1. Get a free API key: themoviedb.org → Settings → API.
2. Copy `.env.example` to `.env` and paste your key.
3. `npm install && npm run dev`

## Deploy
Push to GitHub, import on Vercel/Netlify, add `VITE_TMDB_KEY` in the project's Environment Variables, build `npm run build`, output `dist`.

## Requirement map
Search Movies, View Details (/movie/:id), Display Ratings, Category (genre) Filters, Responsive Design, Error Handling (missing key, failed request, empty results), Loading Indicators.
Skills: Components, Hooks (useApi, useDebounce), API integration, State management (context.jsx), Routing.
